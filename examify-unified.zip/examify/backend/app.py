"""
Examify Backend - Flask Application
Serves both the REST API and the built React frontend as static files.
Single-server deployment: `python app.py` runs everything.
"""

import os
from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize extensions (created here so models can import db)
db = SQLAlchemy()

# Path to the React production build, sitting one level up from backend/
FRONTEND_BUILD_DIR = os.path.join(os.path.dirname(__file__), '..', 'frontend', 'build')


def create_app():
    """Application factory pattern."""
    app = Flask(
        __name__,
        static_folder=os.path.abspath(FRONTEND_BUILD_DIR),
        static_url_path='',          # serve static assets at root, not /static
    )

    # ── Configuration ──────────────────────────────────────────────────────────
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'examify-dev-secret-key-change-in-prod')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///examify.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50 MB upload cap
    app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')

    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    # ── Extensions ─────────────────────────────────────────────────────────────
    db.init_app(app)

    # CORS is only needed when the frontend is on a different origin (dev mode).
    # In production (Flask serving the build) it is a no-op but harmless.
    CORS(app, resources={r'/api/*': {'origins': '*'}})

    # ── API Blueprints ─────────────────────────────────────────────────────────
    from routes.upload import upload_bp
    from routes.questions import questions_bp
    from routes.sessions import sessions_bp

    app.register_blueprint(upload_bp,    url_prefix='/api')
    app.register_blueprint(questions_bp, url_prefix='/api')
    app.register_blueprint(sessions_bp,  url_prefix='/api')

    # ── Database ───────────────────────────────────────────────────────────────
    with app.app_context():
        db.create_all()

    # ── API utility routes ─────────────────────────────────────────────────────
    @app.route('/api/health')
    def health():
        return jsonify(status='ok', message='Examify API is running')

    # ── Frontend static-file serving ───────────────────────────────────────────
    # React's build/ contains index.html plus hashed JS/CSS bundles.
    # Any path that is NOT an /api/* route should fall through to index.html so
    # that React Router can handle client-side navigation (/, /upload, /quiz/3, …).

    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve_frontend(path):
        """
        1. If the path matches a real file in the build folder
           (e.g. static/js/main.abc123.js, favicon.ico) → serve it directly.
        2. Otherwise → return index.html so React Router takes over.
        """
        static_folder = app.static_folder

        if static_folder and path:
            full_path = os.path.join(static_folder, path)
            if os.path.isfile(full_path):
                return send_from_directory(static_folder, path)

        # Fall back to index.html for all React routes
        index = os.path.join(static_folder, 'index.html') if static_folder else None
        if index and os.path.isfile(index):
            return send_from_directory(static_folder, 'index.html')

        # Build not found → helpful message for developers
        return jsonify(
            error='Frontend build not found.',
            hint='Run `cd frontend && npm install && npm run build` first.',
        ), 404

    # ── Error handlers ─────────────────────────────────────────────────────────
    @app.errorhandler(413)
    def file_too_large(e):
        return jsonify(error='File too large. Maximum size is 50 MB.'), 413

    @app.errorhandler(404)
    def not_found(e):
        # API 404s return JSON; all other 404s fall to serve_frontend above.
        return jsonify(error='Resource not found.'), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify(error='Internal server error.'), 500

    return app


if __name__ == '__main__':
    application = create_app()
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    print(f'\n🎓  Examify running at http://localhost:{port}\n')
    application.run(host='0.0.0.0', port=port, debug=debug)
